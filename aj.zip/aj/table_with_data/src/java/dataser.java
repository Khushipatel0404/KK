/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kunda
 */
@WebServlet(urlPatterns = {"/dataser"})
public class dataser extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
//  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
//        throws ServletException, IOException {
//
//    // Correct content type for Excel
//    response.setContentType("application/xls");
//
//    // Set header to force download with a filename
//    response.setHeader("Content-Disposition", "attachment; filename=\"data.xls\"");
//
//    try (PrintWriter out = response.getWriter()) {
//
//        // Write Excel-style tabular data (TSV or CSV format)
//        out.println("Roll No\tName\tMarks");
//        out.println("1\tkhushi\t85");
//        out.println("2\tdiya\t90");
//        out.println("3\tkrisha\t78");
//    }
//}



protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

// exel foramte chnage 
// // Set content type for Word document
//    response.setContentType("application/xls");
//
//    // Set header to suggest file name
//    response.setHeader("Content-Disposition", "attachment; filename=\"report.xls\"");
////


    // Set content type for Word document
    response.setContentType("application/msword");

    // Set header to suggest file name
    response.setHeader("Content-Disposition", "attachment; filename=\"report.doc\"");
//
//    try (PrintWriter out = response.getWriter()) {
//        out.println("<html>");
//        out.println("<head><title>Word Document</title></head>");
//        out.println("<body>");
//        out.println("<h2 style='color:#e60073;'>Student Marks Report</h2>");
//
//        // Table in HTML
//        out.println("<table border='1' cellpadding='10'>");
//        out.println("<tr><th>Roll No</th><th>Name</th><th>Marks</th></tr>");
//        out.println("<tr><td>1</td><td>khushi</td><td>85</td></tr>");
//        out.println("<tr><td>2</td><td>diya</td><td>90</td></tr>");
//        out.println("<tr><td>3</td><td>krisha</td><td>78</td></tr>");
//        out.println("</table>");
//
//        out.println("</body>");
//        out.println("</html>");
////    }




//try (PrintWriter out = response.getWriter()) {
//    out.println("<html>");
//    out.println("<head><title>Word Document</title></head>");
//    out.println("<body>");
//    out.println("<h2 style='color:#e60073;'>Student Marks Report</h2>");
//
//    // Table Start
//    out.println("<table border='1' cellpadding='10'>");
//    out.println("<tr><th>Roll No</th><th>Name</th><th>Marks</th></tr>");
//
//    // Rows
//    out.println("<tr><td>1</td><td>khushi</td><td>85</td></tr>");
//    out.println("<tr><td>2</td><td>diya</td><td>90</td></tr>");
//    out.println("<tr><td>3</td><td>krisha</td><td>78</td></tr>");
//
//    // Total calculation
//    int total = 85 + 90 + 78;
//
//    // Total Row
//    out.println("<tr>");
//    out.println("<td colspan='2'><strong>Total</strong></td>");
//    out.println("<td><strong>" + total + "</strong></td>");
//    out.println("</tr>");
//
//    out.println("</table>");
//    out.println("</body>");
//    out.println("</html>");
//}
//
//}

try (PrintWriter out = response.getWriter()) {
        out.println("<html>");
        out.println("<head><title>Student Report</title></head>");
        out.println("<body>");
        out.println("<h2 style='color:#e60073; text-align: center;'>Student Marks Report</h2>");

        out.println("<table border='1' cellpadding='10' cellspacing='0' style='width: 50%; margin: auto; text-align: center;'>");
        out.println("<tr style='background-color: #ffd6e6;'><th>Roll No</th><th>Name</th><th>Marks</th></tr>");

        // Data rows
        out.println("<tr><td>1</td><td>khushi</td><td>85</td></tr>");
        out.println("<tr><td>2</td><td>diya</td><td>90</td></tr>");
        out.println("<tr><td>3</td><td>krisha</td><td>78</td></tr>");

        // Total
        int total = 85 + 90 + 78;

        out.println("<tr style='font-weight: bold; background-color: #f2f2f2;'>");
        out.println("<td colspan='2'>Total</td>");
        out.println("<td>" + total + "</td>");
        out.println("</tr>");

        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
    }
}
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
