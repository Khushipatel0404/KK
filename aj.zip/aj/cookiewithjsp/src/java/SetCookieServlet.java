/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kunda
 */
//@WebServlet(urlPatterns = {"/SetCookieServlet"})
@WebServlet("/setCookie")
public class SetCookieServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Cookie userCookie = new Cookie("username","NetBeansUser");
        userCookie.setMaxAge(24 * 60 *60);
        response.addCookie(userCookie);
        response.setContentType("text/html");
        response.getWriter().println("<h2>Cookie 'username' has been set</h2>");
        response.getWriter().println("<a href='index.jsp'>Go Back</a>");
            }


}
