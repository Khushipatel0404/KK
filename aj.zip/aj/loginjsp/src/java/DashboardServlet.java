import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/DashboardServlet"})
public class DashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter(); 
        
        HttpSession session = request.getSession(false); 
        String username = (session != null) ? (String) session.getAttribute("username") : null;

        if (username != null) {
            out.println("<h1>Welcome, " + username + "!</h1>");
            out.println("<p>You are being tracked in this session.</p>");
            out.println("<a href='LogoutServlet'>Logout</a>");
        } else {
            out.println("<h1>Session expired or not found</h1>");
            out.println("<p>Please <a href='login.jsp'>Login Again</a>.</p>");
        }
    }
}
