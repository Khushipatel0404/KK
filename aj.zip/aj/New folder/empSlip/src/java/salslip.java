import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/salslip"})
public class salslip extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String ename = request.getParameter("ename");
        double basic = Double.parseDouble(request.getParameter("basic"));
        
        double hra = basic * 0.20;
        double da = basic * 0.15;
        double pf = basic * 0.12;
        double gross = basic + hra + da;
        double net = gross = pf;
        
        request.setAttribute("ename", ename);
        request.setAttribute("basic", basic);
        request.setAttribute("hra", hra);
        request.setAttribute("da", da);
        request.setAttribute("pf", pf);
        request.setAttribute("gross", gross);
        request.setAttribute("net", net);
        
        request.getRequestDispatcher("result.jsp").forward(request,response);   
    }
}
