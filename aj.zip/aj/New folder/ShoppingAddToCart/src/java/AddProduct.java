/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

/**
 *
 * @author kunda
 */
@WebServlet(urlPatterns = {"/AddProduct"})
public class AddProduct extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
String[] products = request.getParameterValues("product");
HttpSession session = request.getSession();
@SuppressWarnings("unchecked")
         ArrayList<String> cart =(ArrayList<String>)session.getAttribute("cart");

if(cart == null){
      cart = new ArrayList<>();
}
if (products != null){
cart.addAll(Arrays.asList(products));
}

session.setAttribute("cart",cart);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h3>Product added to cart.</h3>");
        out.println("<a href='viewCart'> View Cart</a>");
    }


}
