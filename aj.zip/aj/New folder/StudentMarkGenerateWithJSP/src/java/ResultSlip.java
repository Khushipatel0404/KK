import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/ResultSlip"})
public class ResultSlip extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String studentName = request.getParameter("studentName");
        int ml = Integer.parseInt(request.getParameter("ml"));
        int ada = Integer.parseInt(request.getParameter("ada"));
        
        int total = ml + ada;
        String grade;
        
        double percentage = (total / 200.0) * 100;  // assuming 100 marks each
        
        if (percentage >= 85) {
            grade = "A";
        } else if (percentage >= 70) {
            grade = "B";
        } else if (percentage >= 50) {
            grade = "C";
        } else {
            grade = "Fail";
        }
        
        // Set attributes for JSP
        request.setAttribute("studentName", studentName);
        request.setAttribute("ml", ml);
        request.setAttribute("ada", ada);
        request.setAttribute("total", total);
        request.setAttribute("percentage", percentage);
        request.setAttribute("grade", grade);
        
        request.getRequestDispatcher("result.jsp").forward(request, response);
    }
}
