/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kunda
 */
@WebServlet(urlPatterns = {"/SyllabusServlet"})
public class SyllabusServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String yearParam = request.getParameter("year");
        String filePath = null;
        switch (yearParam)
        {
            case "1":
                filePath ="WEB-INF/A.pdf";
                break;
            case "2":
                filePath ="WEB-INF/B.pdf";
                break;
            case "3":
                filePath ="WEB-INF/C.pdf";
                break;
            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid Year parametr. Use 1 ,2, or 3.");
                return;


        }
response.setContentType("application/pdf");
try(InputStream in = getServletContext().getResourceAsStream(filePath);
    OutputStream out = response.getOutputStream())
{
     if(in == null){
     response.sendError(HttpServletResponse.SC_NOT_FOUND,"Syllabus file not found");
     return;
    }
     byte[] buffer = new byte[4096];
     int bytesRead;
     while ((bytesRead = in.read(buffer)) != -1)
{ out.write(buffer, 0,bytesRead);
}
}}}

   
//    @Override
//    public String getServletInfo() {
//        return "Short description";
//    }// </editor-fold>


