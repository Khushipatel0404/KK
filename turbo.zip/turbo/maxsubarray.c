#include <stdio.h>
#include <conio.h>
#include <limits.h>

struct maxsubarray {
    int low;
    int high;
    int sum;
};

// Function to find max crossing subarray
struct maxsubarray find_max_crossing_subarray(int a[], int low, int mid, int high) {
    int left_sum = INT_MIN;
    int sum = 0, max_left = mid, max_right = mid;
    struct maxsubarray result;

    for (int i = mid; i >= low; i--) {
        sum = sum + a[i];
        if (sum > left_sum) {
            left_sum = sum;
            max_left = i;
        }
    }

    int right_sum = INT_MIN;
    sum = 0;
    for (int j = mid + 1; j <= high; j++) {
        sum = sum + a[j];
        if (sum > right_sum) {
            right_sum = sum;
            max_right = j;
        }
    }

    result.low = max_left;
    result.high = max_right;
    result.sum = left_sum + right_sum;
    return result;
}

// Recursive function to find max subarray
struct maxsubarray find_max_subarray(int a[], int low, int high) {
    if (low == high) {
        struct maxsubarray base;
        base.low = low;
        base.high = high;
        base.sum = a[low];
        return base;
    }

    int mid = (low + high) / 2;

    struct maxsubarray left = find_max_subarray(a, low, mid);
    struct maxsubarray right = find_max_subarray(a, mid + 1, high);
    struct maxsubarray cross = find_max_crossing_subarray(a, low, mid, high);

    if (left.sum >= right.sum && left.sum >= cross.sum)
        return left;
    else if (right.sum >= left.sum && right.sum >= cross.sum)
        return right;
    else
        return cross;
}

void main() {
    int n, i;
    int a[50];
    struct maxsubarray result;

    clrscr();

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    result = find_max_subarray(a, 0, n - 1);

    printf("\nMaximum Subarray is from index %d to %d\n", result.low, result.high);
    printf("Maximum Sum = %d\n", result.sum);

    printf("Subarray elements: ");
    for (i = result.low; i <= result.high; i++) {
        printf("%d ", a[i]);
    }

    getch();
}

