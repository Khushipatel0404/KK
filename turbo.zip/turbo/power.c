#include <stdio.h>
#include <conio.h>

long power(int base, int exp) {
    long result = 1;
    int i;

    for (i = 1; i <= exp; i++) {
        result = result * base;
    }

    return result;
}

void main() {
    int base, exp;
    long result;

    clrscr();

    printf("Enter base: ");
    scanf("%d", &base);

    printf("Enter exponent: ");
    scanf("%d", &exp);

    result = power(base, exp);

    printf("%d^%d = %ld", base, exp, result);

    getch();
}
