#include <stdio.h>
#include <conio.h>

void merge(int arr[], int l, int m, int r) {
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;
    int X[10], Y[10];

    for (i = 0; i < n1; i++)
	X[i] = arr[l + i];
    for (j = 0; j < n2; j++)
	Y[j] = arr[m + 1 + j];

    i = 0;
    j = 0;
    k = l;

    while (i < n1 && j < n2) {
	if (X[i] <= Y[j]) {
	    arr[k] = X[i];
	    i++;
	} else {
	    arr[k] = Y[j];
	    j++;
	}
	k++;
    }
    while (i < n1) {
	arr[k] = X[i];
	i++;
	k++;
    }
    while (j < n2) {
	arr[k] = Y[j];
	j++;
	k++;
    }
}
void mergeSort(int arr[], int l, int r) {
    if (l < r) {
	int m = (l + r) / 2;

	mergeSort(arr, l, m);
	mergeSort(arr, m + 1, r);

	merge(arr, l, m, r);
    }
}

void main() {
    int arr[50], n, i;
    clrscr();
    printf("Enter number of elements: ");
    scanf("%d", &n);
    printf("Enter %d elements:\n", n);
    for (i = 0; i < n; i++)
    scanf("%d", &arr[i]);
    mergeSort(arr, 0, n - 1);
    printf("\nSorted array: ");
    for (i = 0; i < n; i++)
    printf("%d ", arr[i]);
    getch();
}