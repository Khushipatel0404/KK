#include <stdio.h>
#include <conio.h>
#include <limits.h>


int min(int a, int b) {
    return (a < b) ? a : b;
}

int coinChange(int coins[], int n, int amt) {
    int C[20][20];
    int i, j;


    for (i = 0; i <= n; i++) {
	C[i][0] = 0;
    }


    for (i = 1; i <= n; i++) {
	for (j = 1; j <= amt; j++) {
	    if (i == 1 && j < coins[i-1]) {
		C[i][j] = INT_MAX - 1;
	    }
	    else if (i == 1 && j >= coins[i-1]) {
		C[i][j] = 1 + C[i][j - coins[i-1]];
	    }
	    else if (j < coins[i-1]) {
		C[i][j] = C[i-1][j];
	    }
	    else {
		C[i][j] = min(C[i-1][j], 1 + C[i][j - coins[i-1]]);
	    }
	}
    }


    printf("\n ");
    printf("      ");
    for (j = 0; j <= amt; j++) {
	printf("%4d", j);
    }
    printf("\n");

    for (i = 1; i <= n; i++) {
	printf("Coin%-2d", coins[i-1]);
	for (j = 0; j <= amt; j++) {
	    if (C[i][j] >= INT_MAX - 1)
		printf("");
	    else
		printf("%4d", C[i][j]);
	}
	printf("\n");
    }

    return C[n][amt];
}

void main() {
    int coins[20], n, amt, i, ans;

    clrscr();
    printf("Enter number of coins: ");
    scanf("%d", &n);

    printf("Enter coin values: ");
    for (i = 0; i < n; i++) {
        scanf("%d", &coins[i]);
    }

    printf("Enter amount to make: ");
    scanf("%d", &amt);

    ans = coinChange(coins, n, amt);

    if (ans >= INT_MAX - 1)
        printf("\nNot possible to make amount %d with given coins\n", amt);
    else
        printf("\nMinimum coins required = %d\n", ans);

    getch();
}
