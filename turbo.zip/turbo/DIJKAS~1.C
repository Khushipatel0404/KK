#include <stdio.h>
#include <conio.h>

int findMinVertex(int length[], int set[], int n) {
    int min = -1, i;
    for (i = 0; i < n; i++) {
        if (set[i] == 0 && (min == -1 || length[i] < length[min]))
            min = i;
    }
    return min;
}

void main() {
    int n, e;
    int g[10][10] = {0};
    int length[10], set[10], path[10];
    int u, v, w, s, i, j;

    clrscr();

    printf("Enter number of vertices and edges: ");
    scanf("%d %d", &n, &e);

    printf("\nEnter edges (u v w):\n");
    for (i = 0; i < e; i++) {
        scanf("%d %d %d", &u, &v, &w);
        g[u][v] = w;
        g[v][u] = w;   // For undirected graph; remove if directed
    }

    // Print adjacency matrix
    printf("\nAdjacency Matrix (Vertex x Vertex):\n");
    printf("    "); // header spacing
    for (i = 0; i < n; i++)
        printf("%3d", i);
    printf("\n");

    for (i = 0; i < n; i++) {
        printf("%3d ", i);
        for (j = 0; j < n; j++)
            printf("%3d", g[i][j]);
        printf("\n");
    }

    printf("\nEnter source vertex: ");
    scanf("%d", &s);

    // Initialization
    for (i = 0; i < n; i++) {
        set[i] = 0;
        length[i] = 9999;  // large number instead of infinity
        path[i] = -1;
    }
    length[s] = 0;

    // Iteration
    for (i = 0; i < n - 1; i++) {
        int u = findMinVertex(length, set, n);
        set[u] = 1;

        for (v = 0; v < n; v++) {
            if (!set[v] && g[u][v] != 0 && length[u] + g[u][v] < length[v]) {
                length[v] = length[u] + g[u][v];
                path[v] = u;
            }
        }
    }

    // Output distances
    printf("\nShortest distances from source %d:\n", s);
    for (i = 0; i < n; i++)
        printf("To vertex %d = %d\n", i, length[i]);

    // Output paths
    printf("\nPaths:\n");
    for (i = 0; i < n; i++) {
        if (i == s)
            continue;
        printf("Path to %d: ", i);
        j = i;
        while (j != -1) {
            printf("%d", j);
            j = path[j];
            if (j != -1)
                printf(" <- ");
        }
        printf("\n");
    }

    getch();
}
