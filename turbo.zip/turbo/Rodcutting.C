#include <stdio.h>

int max(int a, int b) {
	return (a > b) ? a : b;
}

int main() {
    int n, i, j;
    int d[10];
    int c[20][20];
    clrscr();
    printf("Enter rod length: ");
    scanf("%d", &n);
    printf("Enter profit for lengths 1 to %d:\n", n);
    for (i = 1; i < n; i++)
	scanf("%d", &d[i]);
    for (i = 1; i <= n-1; i++)
	    c[i][0] = 0;
    for (i = 1; i <= n-1; i++) {
	for (j = 1; j <=n; j++) {
	if(i==1)
	     c[i][j]=j*d[i];
	    else if (j < i)
		c[i][j] = c[i-1][j];
	    else
		c[i][j] = max(c[i-1][j], d[i] + c[i][j-i]);
	}
    }
    printf("\nMaximum revenue = %d\n", c[n-1][n]);
    printf("\nDP Matrix:\n");
    for (i = 1; i <= n-1; i++) {
	for (j = 0; j <= n; j++) {
	    printf("%4d", c[i][j]);
	}
	printf("\n");
    }
    getch();
}
