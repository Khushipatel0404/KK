// Recursive Binary  Search
#include <stdio.h>
#include <conio.h>

int Binary(int a[], int low, int high, int s) {
    int mid;
    if (low > high)
	return -1;
    mid = (low + high) / 2;
    if (s == a[mid])
	return mid;
    else if (s < a[mid])
	return Binary(a, low, mid - 1, s);
    else
	return Binary(a, mid + 1, high, s);
}

void main() {
    int a[100], n, i, s, result;
    clrscr();
    printf("Enter number elements: ");
    scanf("%d", &n);
    printf("Enter %d sorted elements:\n", n);
    for (i = 0; i < n; i++) {
	scanf("%d", &a[i]);
    }
    printf("Enter element to search: ");
    scanf("%d", &s);
    result = Binary(a, 0, n - 1, s);
    if (result == -1)
	printf("Element not found in the array.\n");
    else
	printf("Element found at position %d (index %d).\n", result + 1, result);
    getch();
}
