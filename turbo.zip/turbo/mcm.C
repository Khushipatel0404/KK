#include<stdio.h>
#include<conio.h>

void print_optimal(int i,int j,int s[10][10])
{
	if(i==j)
	{
		printf("A%d",i);
	}
	else
	{
		printf("(");
		print_optimal(i,s[i][j],s);
		print_optimal(s[i][j]+1,j,s);
		printf(")");
	}
}
void chain(int p[],int size)
{
	int i,j,k,ws,m[10][10],s[10][10],q;
	int n=size-1;
	for(i=1;i<=n;i++)
	{
		m[i][i]=0;
		s[i][i]=0;
	}
	for(ws=2;ws<=n;ws++)
	{
		for(i=1;i<=n-1;i++)
		{
			j=i+(ws-1);
			m[i][j]=9999;

			for(k=i;k<=j-1;k++)
			{
				q=(m[i][k]+m[k+1][j])+p[i-1]*p[k]*p[j];
				if(q<m[i][j])
				{
					m[i][j]=q;
					s[i][j]=k;
				}
			}
		}
	}
	printf("\nM:\n");
	for(i=1;i<=n;i++)
	{
		for(k=1;k<=i;k++)
		{
			printf("\t");
		}
		for(j=i;j<=n;j++){
			printf("%d\t",m[i][j]);
		}
		printf("\n");
	}
	printf("\nS:\n");
	for(i=1;i<=n;i++)
	{
		for(k=1;k<=i;k++)
		{
			printf("\t");
		}
		for(j=i;j<=n;j++)
		{
			printf("%d\t",s[i][j]);
		}
		printf("\n");
	}
      print_optimal(1,n,s);
}
void main()
{
	int i,*p,n;
	clrscr();
	printf("Enter Number of P's => ");
	scanf("%d",&n);
	p=(int *)malloc(n*sizeof(int));
	for(i=0;i<n;i++)
	{
		printf("Enter value of p[%d] => ",i);
		scanf("%d",&p[i]);
	}
	chain(p,n);
	getch();

}