#include <stdio.h>
#include <conio.h>
#include <math.h>

int caldigit(long int no){
 int count=0;
 if(no == 0) return 1;
 while(no>0){
	no=no/10;
	count++;
 }
 return count;
}

long int karatsuba(long int x, long int y){
	long int a,b,c,d,n,digit,POM,p1,p2,p3;
	if (x < 10 || y < 10)
		return x * y;

	digit = caldigit(x);
	if(caldigit(y) > digit)
		digit = caldigit(y);
	n = digit / 2;
	if(n == 0) n = 1;

	POM = (long int)pow(10, n);
	a = x / POM;
	b = x % POM;
	c = y / POM;
	d = y % POM;
	p1 = karatsuba(a, c);
	p2 = karatsuba(b, d);
	p3 = karatsuba(a + b, c + d);

	return p1 * (long int)pow(10, 2 * n) + (p3 - p1 - p2) * (long int)pow(10, n) + p2;
}

void main() {
    long int num1, num2;
    long int re;
    clrscr();
    printf("Enter first number: ");
    scanf("%ld", &num1);
    printf("Enter second number: ");
    scanf("%ld", &num2);

    printf("\nCalculating %ld * %ld using\n", num1, num2);
    
    re = karatsuba(num1, num2);
    printf("Karatsuba result = %ld\n", re);
    
    getch();
}
