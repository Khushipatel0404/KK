#include <stdio.h>
#include <conio.h>

struct knap {
    float p,w,pw,x;   
};
void main() {
    struct knap t[10], temp;
    int n, i, j;
    float M, CU, totalProfit = 0.0, totalWeight = 0.0;
    clrscr();
    printf("Enter number of items: ");
    scanf("%d", &n);
    for(i = 0; i < n; i++) {
        printf("\nEnter profit for item %d: ", i + 1);
        scanf("%f", &t[i].p);
        printf("Enter weight for item %d: ", i + 1);
        scanf("%f", &t[i].w);
        t[i].pw = t[i].p / t[i].w;   
        t[i].x = 0.0;                
    }
    printf("\nEnter knapsack capacity (M): ");
    scanf("%f", &M);
    CU = M;
    for(i = 0; i < n - 1; i++) {
        for(j = i + 1; j < n; j++) {
            if(t[i].pw < t[j].pw) {
                temp = t[i];
                t[i] = t[j];
                t[j] = temp;
            }
        }
    }
    for(i = 0; i < n; i++) {
        if(t[i].w <= CU) {
            t[i].x = 1.0;
            CU -= t[i].w;
        } else {
            t[i].x = CU / t[i].w;
	    CU = 0.0;
	    break;
	}
    }
    for(i = 0; i < n; i++) {
	totalProfit += t[i].p * t[i].x;
	totalWeight += t[i].w * t[i].x;
    }
    printf("\n  Item   Profit  Weight   P/W            X     Used Wt   Used Profit ");
	for(i = 0; i < n; i++) {
    printf("\n  %3d   %6.2f  %6.2f  %6.2f  %10.2f  %8.2f  %12.2f \n",
           i + 1, t[i].p, t[i].w, t[i].pw, t[i].x,
           t[i].w * t[i].x,
           t[i].p * t[i].x);
	}
	printf("\nTOTAL PROFIT:%5.2f", totalProfit);
	getch();
}
