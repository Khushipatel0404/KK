#include <stdio.h>
#include <conio.h>
#include <string.h>

void DFS(int g[20][20], int n, int start, char labels[20][10])
{
    int stack[20], top = -1;
    int visited[20];
    int u, i;
    for (i = 1; i <= n; i++)
        visited[i] = 0;
    u = start;
    stack[++top] = u;
    visited[u] = 1;
    printf("\nDFS Traversal: ");
    while (top != -1)
    {
        u = stack[top--];
        printf("%s ", labels[u]);
        for (i = n; i >= 1; i--)
        {
            if (g[u][i] == 1 && visited[i] == 0)
            {
                stack[++top] = i;
                visited[i] = 1;
            }
        }
    }
}

int findVertex(char labels[20][10], int n, char *label)
{
    int i;
    for (i = 1; i <= n; i++)
    {
        if (strcmp(labels[i], label) == 0)
            return i;
    }
    return -1;
}

void main()
{
    int g[20][20];
    int n, e, i, j;
    char labels[20][10];
    char u_label[10], v_label[10], start_label[10];
    int u, v, start;
    
    clrscr();
    
    printf("Enter number of vertices: ");
    scanf("%d", &n);
    
    printf("Enter vertex labels:\n");
    for (i = 1; i <= n; i++)
    {
        printf("Vertex %d: ", i);
        scanf("%s", labels[i]);
    }
    
    for (i = 1; i <= n; i++)
        for (j = 1; j <= n; j++)
            g[i][j] = 0;
    
    printf("Enter number of edges: ");
    scanf("%d", &e);
    
    printf("Enter edges (format: A B):\n");
    for (i = 1; i <= e; i++)
    {
        scanf("%s %s", u_label, v_label);
        u = findVertex(labels, n, u_label);
        v = findVertex(labels, n, v_label);
        
        if (u != -1 && v != -1)
        {
            g[u][v] = 1;
            g[v][u] = 1;
        }
        else
        {
            printf("Invalid vertex label!\n");
            i--;
        }
    }
    
    printf("\nAdjacency Matrix:\n");
    printf("   ");
    for (i = 1; i <= n; i++)
        printf("%s ", labels[i]);
    printf("\n");
    
    for (i = 1; i <= n; i++)
    {
        printf("%s  ", labels[i]);
        for (j = 1; j <= n; j++)
            printf("%d ", g[i][j]);
        printf("\n");
    }
    
    printf("\nEnter start vertex: ");
    scanf("%s", start_label);
    start = findVertex(labels, n, start_label);
    
    if (start != -1)
        DFS(g, n, start, labels);
    else
        printf("Invalid start vertex!\n");
    
    getch();
}