#include <stdio.h>
#include <conio.h>

void main()
{
    int n, e, i, j;
    int g[20][20], visited[20], cost = 0;
    int a, b, u, v, min, ne = 1, INF = 9999;

    clrscr();
    printf("Enter number of vertices: ");
    scanf("%d", &n);
    printf("Enter number of edges: ");
    scanf("%d", &e);

    for (i = 1; i <= n; i++)
        for (j = 1; j <= n; j++)
            g[i][j] = INF;

    for (i = 1; i <= e; i++) {
        printf("\nEdge %d:\n", i);
        printf(" Enter start vertex: ");
        scanf("%d", &a);
        printf(" Enter end vertex: ");
        scanf("%d", &b);
        printf(" Enter weight: ");
        scanf("%d", &g[a][b]);
        g[b][a] = g[a][b];
    }

    printf("\nAdjacency Matrix:\n");
    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++)
            printf("%4d", g[i][j] == INF ? 0 : g[i][j]);
        printf("\n");
    }

    for (i = 1; i <= n; i++)
        visited[i] = 0;

    visited[1] = 1;
    printf("\nEdges in Minimum Spanning Tree:\n");

    while (ne < n) {
        min = INF;
        for (i = 1; i <= n; i++) {
            if (visited[i]) {
                for (j = 1; j <= n; j++) {
                    if (!visited[j] && g[i][j] < min) {
                        min = g[i][j];
                        u = i;
                        v = j;
                    }
                }
            }
        }
        visited[v] = 1;
        printf(" Edge %d: %d - %d  weight = %d\n", ne, u, v, min);
        cost += min;
        ne++;
    }

    printf("\nTotal Minimum Cost = %d\n", cost);
    getch();
}
