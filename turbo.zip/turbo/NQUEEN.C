#include <stdio.h>
#include <conio.h>

int x[20], n;

int safe(int k) {
    int i;
    for (i = 1; i < k; i++)
        if (x[i] == x[k] || (i - x[i]) == (k - x[k]) || (i + x[i]) == (k + x[k]))
            return 0;
    return 1;
}

void show() {
    int i, j;
    printf("\n");
    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++)
            printf(x[i] == j ? " Q " : " - ");
        printf("\n");
    }
}

void main() {
    int k;
    clrscr();

    printf("Enter number of queens: ");
    scanf("%d", &n);

    for (k = 1; k <= n; k++) x[k] = 0;
    k = 1;

    while (k > 0) {
        x[k]++;

        while (x[k] <= n && !safe(k))
            x[k]++;

        if (x[k] <= n) {
            if (k == n) show();
            else x[++k] = 0;
        } else
            k--;
    }

    getch();
}