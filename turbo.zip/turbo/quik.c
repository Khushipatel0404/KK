#include <stdio.h>
#include <conio.h>

void quick(int a[], int low, int high) {
    int i = low, j = high, pivot = a[(low + high) / 2], temp;

    while (i <= j) {
        while (a[i] < pivot) i++;
        while (a[j] > pivot) j--;
        if (i <= j) {
            temp = a[i]; a[i] = a[j]; a[j] = temp;
            i++; j--;
        }
    }
    if (low < j) quick(a, low, j);
    if (i < high) quick(a, i, high);
}

void main() {
    int a[50], n, i;
    clrscr();

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter elements: ");
    for (i = 0; i < n; i++) scanf("%d", &a[i]);

    quick(a, 0, n - 1);

    printf("Sorted array: ");
    for (i = 0; i < n; i++) printf("%d ", a[i]);

    getch();
}
