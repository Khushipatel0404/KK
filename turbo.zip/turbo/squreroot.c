#include <stdio.h>
#include <conio.h>
#include <math.h>

void main() {
    double num, result;

    clrscr();

    printf("Enter a number: ");
    scanf("%lf", &num);

    if (num < 0) {
        printf("Square root of negative number is not real.");
    } else {
        result = sqrt(num);
        printf("Square root of %.2lf = %.4lf", num, result);
    }

    getch();
}
