#include <stdio.h>
#include <limits.h>

int main() {
    int n, i, j, k, L;

    /* All arrays must be declared BEFORE any input statements */
    int key[50], freq[50];
    int cost[50][50], sum[50][50];

    printf("Enter number of keys: ");
    scanf("%d", &n);

    printf("Enter %d keys in sorted order:\n", n);
    for(i = 0; i < n; i++)
        scanf("%d", &key[i]);

    printf("Enter %d frequencies:\n", n);
    for(i = 0; i < n; i++)
        scanf("%d", &freq[i]);

    /* Initialize diagonals */
    for(i = 0; i < n; i++) {
        cost[i][i] = freq[i];
        sum[i][i] = freq[i];
    }

    /* L = chain length */
    for(L = 2; L <= n; L++) {
        for(i = 0; i <= n - L; i++) {
            j = i + L - 1;

            cost[i][j] = INT_MAX;
            sum[i][j] = sum[i][j - 1] + freq[j];

            for(k = i; k <= j; k++) {
                int left  = (k > i) ? cost[i][k - 1] : 0;
                int right = (k < j) ? cost[k + 1][j] : 0;

                int c = left + right + sum[i][j];

                if(c < cost[i][j])
                    cost[i][j] = c;
            }
        }
    }

    printf("\nMinimum cost of Optimal BST = %d\n", cost[0][n - 1]);

    return 0;
}
